cat interface_raw | awk '{print$1" "$5" "$6" "$7}' | grep Eth | sed -e s/Eth/Ethernet/g | sed -e s/\\//_/g | sed -e s/###//g > /home/busan/room/pjh/interface_data.txt
cat interface_raw | awk '{print$1" "$2" "$3}' | grep -Ev Eth | sed -e s/\\//_/g | sed -e s/###//g | sed -e s/#//g >> /home/busan/room/pjh/interface_data.txt
