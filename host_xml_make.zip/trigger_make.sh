#!/bin/sh

if [ $# -lt 1 ]
then
    echo
    echo "Format ERROR!!!"
    echo
    echo "Usage >>> ./trigger_make.sh host_ip"
    echo
    echo "Example >>> ./trigger_make.sh 10.16.0.73"
    exit
fi


ip=$1


cat /home/busan/room/pjh/interface_data.txt | awk -v myip=$ip '
{
#	print myip

#        split($1,if_name,"_")
#        if_name_first=if_name[1]
#        if_name_last=if_name[2]
#        print if_name_first
#        print if_name_last
        
          print "        <trigger>"
          print "            <expression>{"myip ":"$1"_IN.last()}=0</expression>"
          print "            <recovery_mode>0</recovery_mode>"
          print "            <recovery_expression/>"
          print "            <name>"$1"_In_no_traffic("$2" "$3" "$4") </name>"
          print "            <correlation_mode>0</correlation_mode>"
          print "            <correlation_tag/>"
          print "            <url/>"
          print "            <status>0</status>"
          print "            <priority>4</priority>"
          print "            <description/>"
          print "            <type>0</type>"
          print "            <manual_close>1</manual_close>"
          print "            <dependencies/>"
          print "            <tags/>"
          print "        </trigger>"
          print "        <trigger>"
          print "            <expression>{"myip ":"$1"_OUT.last()}=0</expression>"
          print "            <recovery_mode>0</recovery_mode>"
          print "            <recovery_expression/>"
          print "            <name>"$1"_Out_no_traffic("$2" "$3" "$4") </name>"
          print "            <correlation_mode>0</correlation_mode>"
          print "            <correlation_tag/>"
          print "            <url/>"
          print "            <status>0</status>"
          print "            <priority>4</priority>"
          print "            <description/>"
          print "            <type>0</type>"
          print "            <manual_close>1</manual_close>"
          print "            <dependencies/>"
          print "            <tags/>"
          print "        </trigger>"

}'
