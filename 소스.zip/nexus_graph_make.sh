#!/bin/sh

if [ $# -lt 1 ]
then
    echo
    echo "Format ERROR!!!"
    echo
    echo "Usage >>> ./trigger_make.sh host_ip"
    echo
    echo "Example >>> ./trigger_make.sh 10.16.0.73"
    exit
fi


ip=$1
sys=$2

cat /home/busan/room/pjh/interface_data.txt | awk -v myip=$ip '
BEGIN {
        print "    <graphs>" 
}


{

        print "        <graph>"
        print "            <name>"$1"</name>"
        print "            <width>900</width>"
        print "            <height>200</height>"
        print "            <yaxismin>0.0000</yaxismin>"
        print "            <yaxismax>100.0000</yaxismax>"
        print "            <show_work_period>1</show_work_period>"
        print "            <show_triggers>1</show_triggers>"
        print "            <type>0</type>"
        print "            <show_legend>1</show_legend>"
        print "            <show_3d>0</show_3d>"
        print "            <percent_left>0.0000</percent_left>"
        print "            <percent_right>0.0000</percent_right>"
        print "            <ymin_type_1>0</ymin_type_1>"
        print "            <ymax_type_1>0</ymax_type_1>"
        print "            <ymin_item_1>0</ymin_item_1>"
        print "            <ymax_item_1>0</ymax_item_1>"
        print "            <graph_items>"
        print "                <graph_item>"
        print "                    <sortorder>0</sortorder>"
        print "                    <drawtype>0</drawtype>"
        print "                    <color>1A7C11</color>"
        print "                    <yaxisside>0</yaxisside>"
        print "                    <calc_fnc>2</calc_fnc>"
        print "                    <type>0</type>"
        print "                    <item>"
        print "                        <host>"myip"</host>"
        print "                        <key>'"${sys}"'_"$1"_IN</key>"
        print "                    </item>"
        print "                </graph_item>"
        print "                <graph_item>"
        print "                    <sortorder>1</sortorder>"
        print "                    <drawtype>0</drawtype>"
        print "                    <color>F63100</color>"
        print "                    <yaxisside>0</yaxisside>"
        print "                    <calc_fnc>2</calc_fnc>"
        print "                    <type>0</type>"
        print "                    <item>"
        print "                        <host>"myip"</host>"
        print "                        <key>'"${sys}"'_"$1"_OUT</key>"
        print "                    </item>"
        print "                </graph_item>"
        print "            </graph_items>"
        print "        </graph>"

}
END {
        print "    </graphs>"
	print "</zabbix_export>"
}' > /home/busan/room/pjh/graph

