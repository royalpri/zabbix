#!/bin/sh

if [ $# -lt 1 ]
then
    echo
    echo "Format ERROR!!!"
    echo
    echo "Usage >>> ./nexus_item_make.sh host_ip system"
    echo
    echo "Example >>> ./nexus_item_make.sh 10.16.0.73 6509"
    exit
fi


ip=$1
sys=$2
grp=$3

        echo   "<?xml version='1.0' encoding='UTF-8'?>"
	echo   "<zabbix_export>"
	echo   "    <version>3.4</version>"
 	echo   "    <date>`date +%Y-%m-%dT%H:%M:%SZ`</date>"
	echo   "    <groups>"
	echo   "        <group>"
	echo   "            <name>$grp</name>"
	echo   "        </group>"
	echo   "    </groups>"
	echo   "    <hosts>"
	echo   "        <host>"
	echo   "            <host>$ip</host>"
	echo   "            <name>$sys</name>"
	echo   "            <description/>"
	echo   "            <proxy/>"
        echo   "            <status>0</status>"
	echo   "            <ipmi_authtype>-1</ipmi_authtype>"
	echo   "            <ipmi_privilege>2</ipmi_privilege>"
	echo   "            <ipmi_username/>"
	echo   "            <ipmi_password/>"
	echo   "            <tls_connect>1</tls_connect>"
	echo   "            <tls_accept>1</tls_accept>"
	echo   "            <tls_issuer/>"
	echo   "            <tls_subject/>"
	echo   "            <tls_psk_identity/>"
	echo   "            <tls_psk/>"
	echo   "            <templates>"
	echo   "                <template>"
	echo   "                    <name>5G_CORE_CISCO_Template</name>"
	echo   "                </template>"
	echo   "            </templates>"
	echo   "            <groups>"
	echo   "                <group>"
	echo   "                    <name>$grp</name>"
	echo   "                </group>"
	echo   "            </groups>"
	echo   "            <interfaces>"
	echo   "                <interface>"
	echo   "                    <default>1</default>"
	echo   "                    <type>2</type>"
	echo   "                    <useip>1</useip>"
	echo   "                    <ip>$ip</ip>"
	echo   "                    <dns/>"
	echo   "                    <port>161</port>"
	echo   "                    <bulk>1</bulk>"
	echo   "                    <interface_ref>if1</interface_ref>"
	echo   "                </interface>"
	echo   "            </interfaces>"
	echo   "            <applications/>"



