cat interface_raw | awk '{print$1" "$5" "$6" "$7}' | grep Eth | sed -e s/Eth/Ethernet/g | sed -e s/\\//_/g | sed -e s/###//g > /home/busan/room/pjh/interface_data.txt
cat interface_raw | awk '{print$1" "$2" "$3}' | egrep 'Vl|Vlan' | sed -e s/\\//_/g | sed -e s/###//g | sed -e s/#//g >> /home/busan/room/pjh/interface_data.txt
cat interface_raw | awk '{print$1" "$5" "$6" "$7}' | egrep Po | sed -e s/\\//_/g | sed -e s/Po/port-channel/g | sed -e s/###//g | sed -e s/#//g >> /home/busan/room/pjh/interface_data.txt
