#!/bin/sh

if [ $# -lt 1 ]
then
    echo
    echo "Format ERROR!!!"
    echo
    echo "Usage >>> ./nexus_item_make.sh host_ip system"
    echo
    echo "Example >>> ./nexus_item_make.sh 10.16.0.73 6509"
    exit
fi


ip=$1
sys=$2
grp=$3
com=$4



cat /home/busan/room/pjh/interface_data.txt | awk -v myip=$ip '
BEGIN {
	print	"            <items>"
        print   "                <item>"
        print   "                    <name>CPU_5분통계</name>"
        print   "                    <type>4</type>"
        print   "                    <snmp_community>'"${com}"'</snmp_community>"
        print   "                    <snmp_oid>1.3.6.1.4.1.9.9.109.1.1.1.1.8.1</snmp_oid>"
        print   "                    <key>CPU_RP0</key>"
        print   "                    <delay>5m</delay>"
        print   "                    <history>8d</history>"
        print   "                    <trends>8d</trends>"
        print   "                    <status>0</status>"
        print   "                    <value_type>3</value_type>"
        print   "                    <allowed_hosts/>"
        print   "                    <units>%</units>"
        print   "                    <snmpv3_contextname/>"
        print   "                    <snmpv3_securityname/>"
        print   "                    <snmpv3_securitylevel>0</snmpv3_securitylevel>"
        print   "                    <snmpv3_authprotocol>0</snmpv3_authprotocol>"
        print   "                    <snmpv3_authpassphrase/>"
        print   "                    <snmpv3_privprotocol>0</snmpv3_privprotocol>"
        print   "                    <snmpv3_privpassphrase/>"
        print   "                    <params/>"
        print   "                    <ipmi_sensor/>"
        print   "                    <authtype>0</authtype>"
        print   "                    <username/>"
        print   "                    <password/>"
        print   "                    <publickey/>"
        print   "                    <privatekey/>"
        print   "                    <port/>"
        print   "                    <description/>"
        print   "                    <inventory_link>0</inventory_link>"
        print   "                    <applications/>"
        print   "                    <valuemap/>"
        print   "                    <logtimefmt/>"
        print   "                    <preprocessing/>"
        print   "                    <jmx_endpoint/>"
        print   "                    <master_item/>"
        print   "                    <interface_ref>if1</interface_ref>"
        print   "                </item>"
}
{

        split($1,if_name,"_")
        if_name_first=if_name[1]
        if_name_last=if_name[2]
        if_desc=$NF
        #print if_name_first
        #print if_name_last


        print   "                <item>"
        print   "                    <name>"$1"_[대국:"if_desc"_IN]</name>"
        print   "                    <type>4</type>"
        print   "                    <snmp_community>'"${com}"'</snmp_community>"

        if (length(if_name_last) > 0)
        {
        print   "                    <snmp_oid>ifHCInOctets[&quot;index&quot;,&quot;ifDescr&quot;,&quot;"if_name_first"/"if_name_last"&quot;]</snmp_oid>"
        }
        else
        {
        print   "                    <snmp_oid>ifHCInOctets[&quot;index&quot;,&quot;ifDescr&quot;,&quot;"if_name_first"&quot;]</snmp_oid>"
        }
        print   "                    <key>'"${sys}"'_"$1"_IN</key>"
        print   "                    <delay>5m</delay>"
        print   "                    <history>8d</history>"
        print   "                    <trends>8d</trends>"
        print   "                    <status>0</status>"
        print   "                    <value_type>3</value_type>"
        print   "                    <allowed_hosts/>"
        print   "                    <units>bps</units>"
        print   "                    <snmpv3_contextname/>"
        print   "                    <snmpv3_securityname/>"
        print   "                    <snmpv3_securitylevel>0</snmpv3_securitylevel>"
        print   "                    <snmpv3_authprotocol>0</snmpv3_authprotocol>"
        print   "                    <snmpv3_authpassphrase/>"
        print   "                    <snmpv3_privprotocol>0</snmpv3_privprotocol>"
        print   "                    <snmpv3_privpassphrase/>"
        print   "                    <params/>"
        print   "                    <ipmi_sensor/>"
        print   "                    <authtype>0</authtype>"
        print   "                    <username/>"
        print   "                    <password/>"
        print   "                    <publickey/>"
        print   "                    <privatekey/>"
        print   "                    <port/>"
        print   "                    <description/>"
        print   "                    <inventory_link>0</inventory_link>"
        print   "                    <applications/>"
        print   "                    <valuemap/>"
        print   "                    <logtimefmt/>"
        print   "                    <preprocessing>"
        print   "                       <step>"
        print   "                               <type>10</type>"
        print   "                               <params/>"
        print   "                       </step>"
        print   "                       <step>"
        print   "                               <type>1</type>"
        print   "                               <params>8</params>"
        print   "                       </step>"
        print   "                    </preprocessing>"
        print   "                    <jmx_endpoint/>"
        print   "                    <master_item/>"
        print   "                    <interface_ref>if1</interface_ref>"
        print   "                </item>"
        print   "                <item>"
        print   "                    <name>"$1"_[대국:"if_desc"_OUT]</name>"
        print   "                    <type>4</type>"
        print   "                    <snmp_community>'"${com}"'</snmp_community>"

        if (length(if_name_last) > 0)
        {
        print   "                    <snmp_oid>ifHCOutOctets[&quot;index&quot;,&quot;ifDescr&quot;,&quot;"if_name_first"/"if_name_last"&quot;]</snmp_oid>"
        }
        else
        {
        print   "                    <snmp_oid>ifHCOutOctets[&quot;index&quot;,&quot;ifDescr&quot;,&quot;"if_name_first"&quot;]</snmp_oid>"
        }

        print   "                    <key>'"${sys}"'_"$1"_OUT</key>"
        print   "                    <delay>5m</delay>"
        print   "                    <history>8d</history>"
        print   "                    <trends>8d</trends>"
        print   "                    <status>0</status>"
        print   "                    <value_type>3</value_type>"
        print   "                    <allowed_hosts/>"
        print   "                    <units>bps</units>"
        print   "                    <snmpv3_contextname/>"
        print   "                    <snmpv3_securityname/>"
        print   "                    <snmpv3_securitylevel>0</snmpv3_securitylevel>"
        print   "                    <snmpv3_authprotocol>0</snmpv3_authprotocol>"
        print   "                    <snmpv3_authpassphrase/>"
        print   "                    <snmpv3_privprotocol>0</snmpv3_privprotocol>"
        print   "                    <snmpv3_privpassphrase/>"
        print   "                    <params/>"
        print   "                    <ipmi_sensor/>"
        print   "                    <authtype>0</authtype>"
        print   "                    <username/>"
        print   "                    <password/>"
        print   "                    <publickey/>"
        print   "                    <privatekey/>"
        print   "                    <port/>"
        print   "                    <description/>"
        print   "                    <inventory_link>0</inventory_link>"
        print   "                    <applications/>"
        print   "                    <valuemap/>"
        print   "                    <logtimefmt/>"
        print   "                    <preprocessing>"
        print   "                       <step>"
        print   "                               <type>10</type>"
        print   "                               <params/>"
        print   "                       </step>"
        print   "                       <step>"
        print   "                               <type>1</type>"
        print   "                               <params>8</params>"
        print   "                       </step>"
        print   "                    </preprocessing>"
        print   "                    <jmx_endpoint/>"
        print   "                    <master_item/>"
        print   "                    <interface_ref>if1</interface_ref>"
        print   "                </item>"

}' > /home/busan/room/pjh/item

