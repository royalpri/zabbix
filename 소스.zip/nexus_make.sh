#!/bin/sh

if [ $# -lt 2 ]
then
    echo
    echo "Format ERROR!!!"
    echo
    echo "Usage >>> ./nexus_make.sh host_ip system group community"
    echo
    echo "Example >>> ./nexus_make.sh 172.21.45.46 sjcc01leaf00-m1 송정Central통신센터 5Gnms1"
    exit
fi


ip=$1
system=$2
grp=$3
com=$4

/home/busan/room/pjh/nexus_interface_gagong.sh
/home/busan/room/pjh/nexus_item_make.sh $ip $system $grp $com
/home/busan/room/pjh/ping_item_make.sh
/home/busan/room/pjh/nexus_trigger_make.sh $ip $system $grp $com
/home/busan/room/pjh/ping_trigger_make.sh $ip
/home/busan/room/pjh/nexus_graph_make.sh $ip $system $grp $com

/home/busan/room/pjh/nexus_host_make.sh $ip $system $grp $com > /home/busan/room/pjh/$system._host.xml
cat /home/busan/room/pjh/item >> /home/busan/room/pjh/$system._host.xml
cat /home/busan/room/pjh/trigger >> /home/busan/room/pjh/$system._host.xml
cat /home/busan/room/pjh/graph >> /home/busan/room/pjh/$system._host.xml
