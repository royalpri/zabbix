#!/bin/sh

if [ $# -lt 1 ]
then
    echo
    echo "Format ERROR!!!"
    echo
    echo "Usage >>> ./ping_trigger_make.sh host_ip"
    echo
    echo "Example >>> ./ping_trigger_make.sh 10.16.0.73"
    exit
fi


host_ip=$1




cat /home/busan/room/pjh/ping_raw | awk '{

	interface=$1
	ip=$2
	desc=$4
        print   "                <trigger>"
        print   "                    <expression>{'"${host_ip}"':icmpping[" ip "].last(#3)}=0</expression>"
        print   "                    <recovery_mode>0</recovery_mode>"
        print   "                    <recovery_expression/>"
        print   "                    <name>"$4"_PING 실패</name>"
        print   "                                <correlation_mode>0</correlation_mode>"
        print   "                                <correlation_tag/>"
        print   "                                <url/>"
        print   "                                <status>0</status>"
        print   "                                <priority>2</priority>"
        print   "                                <description/>"
        print   "                                <type>0</type>"
        print   "                                <manual_close>1</manual_close>"
        print   "                                <dependencies/>"
        print   "                                <tags/>"
        print   "                </trigger>"

}END {
          print "    </triggers>"
}' >> /home/busan/room/pjh/trigger
